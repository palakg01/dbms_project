<?php

  session_start();

  include './db.php';
  $con = createDB();

  $email = $_SESSION['email'];
  $train_no = $_SESSION['train_no'];
  $order_id = $_SESSION['order_id'];
  $amount_paid = $_SESSION['payable_amount'];
  $ticket_id = 'trn'.rand(1111111,99999999).'TKT';
  $_SESSION['ticket_id'] = $ticket_id;

  $sql = "SELECT * FROM train WHERE train_no='$train_no'";
  $result = mysqli_query($con,$sql);

  if ($row = $result->fetch_assoc()) {
    $price = $row['price'];
    $num_of_passengers = $amount_paid/$price;
    $available_seats = $row['available_seats'];
    $waiting  = $row['waiting'];  

    if($available_seats>=$num_of_passengers){
      $available_seats = $available_seats - $num_of_passengers;
    }
    else{
      $waiting = $num_of_passengers - $available_seats;
      $available_seats = 0;
    }
  }

  if($waiting==0){
    $status = 'booked';
  }
  else{
    $status = 'waiting';
  }  

  // $sql = "INSERT INTO ticket (ticket_id) VALUES ('$ticket_id')";

  $sql = "INSERT INTO `ticket` (`ticket_id`,`train_no`,`booked_user`,`order_id`,`booking_status`,`no_of_passengers`) VALUES ('$ticket_id','$train_no','$email','$order_id','$status','$num_of_passengers')";

  $result = mysqli_query($con,$sql);

  if ($result){
    echo '
      
        <h1 class="text-success">Ticket Booked Succesfully!<h1>
        <h3 class">Ticket Details<h3>
        <p>Train No: '.$train_no.'</p>
        <p>Ticket Id: '.$ticket_id.'</p>
        <p>Order Id: '.$order_id.'</p>
        <p>No of passengers: '.$num_of_passengers.'</p>
        <p>Ticket Status: '.$status.'</p>
      
    ';
  }else{
    echo mysqli_error($con);
  }


?>